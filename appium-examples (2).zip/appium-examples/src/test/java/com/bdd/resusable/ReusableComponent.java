package com.bdd.resusable;

import java.io.File;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;



public class ReusableComponent {
	
	
	
	  protected static WebDriver driver;
	  static String sureify="http://demowebshop.tricentis.com/";
	 static String testStepsName="Scr";
	
	
	public   void launchBrowser()throws Throwable{
		//ChromeDriver
		//WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//IE Driver
//		WebDriverManager.iedriver().setup();
//		driver=new InternetExplorerDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	
	//////////LaunchUrl
		public   void launchUrl(){
			driver.get(sureify);
		}
		
		////////verify ElementPresnt or Not Method	
		public   boolean isElementPresent(By by) {
        
        try {
              
               driver.findElement(by ).isDisplayed();
              
               return true ;
              
       } catch(Exception e ) {
              
               return false ;
              
       }
       
       
    }
		
	/////////////////SendChars Method	
		public  void sendChars(By elementBy, String typeChar) throws Exception {

			if (isElementPresent(elementBy)) {

				driver.findElement(elementBy).sendKeys(typeChar);
			}
		}
		
		//////TakeScreenshot
		public  String CaptureScreenShotWithTestStepName()
		{
			try{
				// down casting WebDriver to use getScreenshotAs method.
				TakesScreenshot ts= (TakesScreenshot)driver;
				// capturing screen shot as output type file
				File screenshotSRC= ts.getScreenshotAs(OutputType.FILE);
				// Defining path and extension of image
				String path=System.getProperty("user.dir")+"/ScreenCapturesPNG/"+testStepsName+System.currentTimeMillis()+".png";
				// copying file from temp folder to desired location
				System.out.println("path"+path);
				File screenshotDest= new File(path);
				FileUtils.copyFile(screenshotSRC, screenshotDest);
				return path;
			}catch(Exception e)
			{
				System.out.println("Some exception occured." + e.getMessage());
				return "";
			}
		}
		
		
		public void tearDown()throws Throwable{
			driver.close();
		}
		
		////MouseHover
		public  void mouseHover(By elementBy)throws Throwable{
			WebElement element=driver.findElement(elementBy);
			Actions act=new Actions(driver);
			act.moveToElement(element).perform(); 
		}

		public  void clickElement(By elementBy)throws Throwable {
			// TODO Auto-generated method stub
			driver.findElement(elementBy).click();
		}
		
		public  void authenticatePopup(String userName,String passWord)throws Throwable{
//			WebDriverWait waitAlert=new WebDriverWait(driver,20);
//			Alert alert=waitAlert.until(ExpectedConditions.alertIsPresent());
//			alert.authenticateUsing(userName,passWord);
			driver.switchTo().alert();

			//Selenium-WebDriver Java Code for entering Username & Password as below:

			driver.findElement(By.id("userID")).sendKeys("userName");
			driver.findElement(By.id("password")).sendKeys("myPassword");
			driver.switchTo().alert().accept();
			driver.switchTo().defaultContent();
		}
		
		public  void windowsHandle()throws Throwable{
			String parentWindow=driver.getWindowHandle();
			Set<String> allWindows=driver.getWindowHandles();
			
			for(String childWindow:allWindows){
				driver.switchTo().window(childWindow);
				
			}
			
		}
	



}
