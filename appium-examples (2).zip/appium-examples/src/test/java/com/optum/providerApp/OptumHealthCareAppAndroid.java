package com.optum.providerApp;

import static helpers.Constants.region;

import java.net.URL;

import org.openqa.selenium.MutableCapabilities;
import org.testng.annotations.BeforeTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class OptumHealthCareAppAndroid {
	
	static AndroidDriver<MobileElement> driver;
	static String username = "oauth-sgudapuvalasa9-a7ef6";
	static String accesskey = "d69e148d-6363-48e4-a9a7-0d3bd297ffe4";
	
	public static void main(String[] args) {
		try {
			sauceConnect();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
	}
	
	@BeforeTest
	public static void sauceConnect() throws Exception {
		 System.out.println("Sauce - Connection about to establish...");
	   	        String sauceUrl;
	        if (region.equalsIgnoreCase("eu")) {
	            sauceUrl = "@ondemand.eu-central-1.saucelabs.com:443";
	        } else {
	            sauceUrl = "@ondemand.us-west-1.saucelabs.com:443";
	        }
	        String SAUCE_REMOTE_URL = "https://" + username + ":" + accesskey + sauceUrl +"/wd/hub";
	        System.out.println(SAUCE_REMOTE_URL);
	        URL url = new URL(SAUCE_REMOTE_URL);
	        System.out.println("Sauce access successfull..");
	        
	        MutableCapabilities caps = new MutableCapabilities();
	        caps.setCapability("platformName", "Android");
	        caps.setCapability("appium:platformVersion", "10");
	        caps.setCapability("appium:deviceName", "Samsung Galaxy S9");
	        //caps.setCapability("appium:orientation", "portrait");
	        caps.setCapability("appium:app", "storage:filename=Android.SauceLabs.Mobile.Sample.app.2.7.1.apk");
	        MutableCapabilities sauceOptions = new MutableCapabilities();
	        sauceOptions.setCapability("username", username);
	        sauceOptions.setCapability("accessKey", accesskey);
	        caps.setCapability("sauce:options", sauceOptions);
	        // Launch remote browser and set it as the current thread
	        driver = new AndroidDriver<MobileElement>(url, caps);
	        
	        
	        System.out.println("Application Launched......");
	       
	}
}
