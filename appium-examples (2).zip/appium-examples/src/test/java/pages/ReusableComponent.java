package pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import tests.BaseClass;

public class ReusableComponent extends BaseClass {
	
	
	OptumProviderPO op=new OptumProviderPO();
	homePageMenuPO hp =new homePageMenuPO();
	leftNavigationMenuPO lef=new leftNavigationMenuPO();
	AddTasksPO adt =new AddTasksPO();
	LearningPO lp=new LearningPO();
	MyImpactsPO mi=new MyImpactsPO();
	NotificationsPO not=new NotificationsPO();
	ReSchedulePO resch=new ReSchedulePO();
	scheduleDetailsPO sch=new scheduleDetailsPO();
	TasksListPO tal=new TasksListPO();
	ReScheduleAppointmentsPO res=new ReScheduleAppointmentsPO();
	
	
	
	//public AndroidDriver<WebElement> driver;

	
	 public void appLogo()throws Throwable {
		 try {
			System.out.println("App Logo Method called");
			WebDriverWait wait = new WebDriverWait(driver, 90);
			System.out.println("App Logo Method called Wait method called");
			 WebElement appTitle=wait.until(ExpectedConditions.visibilityOfElementLocated(op.appLogo));			
					 String getTitle=appTitle.getText();
			 
			 System.out.println("Title Validate: "+getTitle);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        }
	 
	 public void validateTitle() {
	        
	    	WebDriverWait wait = new WebDriverWait(driver, 60);

	        WebElement signinTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(op.loginpageTtitle));
	        String getTitle=signinTitle.getText();
	      //  assertEquals("Sign In With Your One Healthcare ID",getTitle);
	        System.out.println("Sign In header Validate: "+getTitle);
	       
	   }
	    
	    public void login(String userName, String passWord) throws Throwable{
	        try {
	      //      driver.context("NATIVE_APP");

//	            WebDriverWait wait0 = new WebDriverWait(driver, 60);
//	            final WebElement usernameHeader = wait0.until(ExpectedConditions.visibilityOfElementLocated(op.usernameIDHeader2));
//	            String uNameHeader=usernameHeader.getText();
	            //Assert.assertEquals("One Healthcare ID or email address",uNameHeader);
	            
	            
	            System.out.println("Coming to login method");
	            WebDriverWait wait1 = new WebDriverWait(driver, 60);
	            WebElement usernameEdit = wait1.until(ExpectedConditions.visibilityOfElementLocated(op.usernameID2));

	            usernameEdit.click();
	            usernameEdit.sendKeys(userName);
	            
	            System.out.println("Entered Username :"+userName);
	            
//	            WebDriverWait wait02 = new WebDriverWait(driver, 60);
//	            final WebElement passwordHeader = wait02.until(ExpectedConditions.visibilityOfElementLocated(op.passwordIDHeader2));
//	            String pwdHeader=passwordHeader.getText();
	            //Assert.assertEquals("Password",pwdHeader);
	            

	            WebDriverWait wait2 = new WebDriverWait(driver, 60);
	            WebElement passwordEdit = wait2.until(ExpectedConditions.visibilityOfElementLocated(op.passwordID2));

	            //WebElement passwordEdit = (WebElement) driver.findElementById(passwordID);
	            passwordEdit.click();
	            passwordEdit.sendKeys(passWord);
	            
	            System.out.println("Entered Password :"+passWord);
	            
	            driver.hideKeyboard();

	            WebDriverWait wait3 = new WebDriverWait(driver, 60);
	            final WebElement submitButton = wait3.until(ExpectedConditions.visibilityOfElementLocated(op.submitButtonID));

	           // WebElement submitButton = (WebElement) driver.findElementByAccessibilityId(submitButtonID);
	            submitButton.click();
	            
	           
	            
	            System.out.println("Login Successfull");
	            
	            Thread.sleep(8000);

	        } catch (Exception e) {
	            System.out.println("*** Problem to login: " + e.getMessage());
	        }
	    }
	    
	    public void invalidlogin(String userName, String invalid_pwd) {
	        try {
	            driver.context("NATIVE_APP");

	            WebDriverWait wait = new WebDriverWait(driver, 60);
	            final WebElement usernameEdit = wait.until(ExpectedConditions.visibilityOfElementLocated(op.usernameID));

	            usernameEdit.click();
	            usernameEdit.sendKeys(userName);
	            
	            System.out.println("Entered Username :"+userName);

	            WebDriverWait wait2 = new WebDriverWait(driver, 60);
	            final WebElement passwordEdit = wait2.until(ExpectedConditions.visibilityOfElementLocated(op.passwordID));

	            //WebElement passwordEdit = (WebElement) driver.findElementById(passwordID);
	            passwordEdit.click();
	            passwordEdit.sendKeys(invalid_pwd);
	            
	            System.out.println("Entered Password :"+invalid_pwd);
	            
	            driver.hideKeyboard();

	            WebDriverWait wait3 = new WebDriverWait(driver, 60);
	            final WebElement submitButton = wait3.until(ExpectedConditions.visibilityOfElementLocated(op.submitButtonID));

	           // WebElement submitButton = (WebElement) driver.findElementByAccessibilityId(submitButtonID);
	            submitButton.click();
	            
	           
	            
	            System.out.println("Login UnSuccessfull");
	            
	            Thread.sleep(3000);
	            
	            WebDriverWait wait4 = new WebDriverWait(driver, 60);
	            final WebElement invalidusermsg = wait4.until(ExpectedConditions.visibilityOfElementLocated(op.invalidUserMsg));
	            String invalidMsg=invalidusermsg.getText();
	            String invalid_uimsg="The One Healthcare ID or password that you entered is incorrect.";
	            Assert.assertEquals(invalid_uimsg,invalidMsg);
	           
	            

	        } catch (Exception e) {
	            System.out.println("*** Problem to login: " + e.getMessage());
	        }
	    }

	    
	    public void validateOTP() throws Throwable {
	        
	    	WebDriverWait wait = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement enterOTP = wait.until(ExpectedConditions.visibilityOfElementLocated(op.signInAccesscode));
	        enterOTP.click();
	        System.out.println("Enter access code...");
	        Thread.sleep(30000);
	        
	        enterOTP.sendKeys("");
	        System.out.println("OTP entered Successfully");
	        
	        WebElement Checkbox = wait.until(ExpectedConditions.visibilityOfElementLocated(op.skipCheckbox));
	        Checkbox.click();
	        System.out.println("Skip checkbox selected");
	        
	        WebElement clkNextbutton = wait.until(ExpectedConditions.visibilityOfElementLocated(op.clickNextbutton));
	        clkNextbutton.click();
	        System.out.println("Next button clicked");
	   }
	    
	    public void homeMenuItems() throws Throwable {
	    	 WebDriverWait wait = new WebDriverWait(driver, 60);
	          WebElement optumHeader = wait.until(ExpectedConditions.visibilityOfElementLocated(hp.optumHeaderTitle));
	          Assert.assertTrue(optumHeader.isDisplayed());
	          
	          WebDriverWait wait1 = new WebDriverWait(driver, 60);
	          WebElement welcomeUserHeader = wait1.until(ExpectedConditions.visibilityOfElementLocated(hp.welcomeHeaderUser));
	          Assert.assertTrue(welcomeUserHeader.isDisplayed());
	         
	            WebDriverWait wait2 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement clkSchedule = wait2.until(ExpectedConditions.visibilityOfElementLocated(hp.clickOnSchedule));
		        Assert.assertTrue(clkSchedule.isDisplayed());
		        
		        WebDriverWait wait3 = new WebDriverWait(driver, 60);
		          WebElement verTasks = wait3.until(ExpectedConditions.visibilityOfElementLocated(hp.clickOnTasks));
		          Assert.assertTrue(verTasks.isDisplayed());
		         
		            WebDriverWait wait4 = new WebDriverWait(driver, 90);
			    	Thread.sleep(30000);
			        WebElement varNotifications = wait4.until(ExpectedConditions.visibilityOfElementLocated(hp.clickOnNotifications));
			        Assert.assertTrue(varNotifications.isDisplayed());
			        
			        WebDriverWait wait5 = new WebDriverWait(driver, 60);
			          WebElement verMyImpact = wait5.until(ExpectedConditions.visibilityOfElementLocated(hp.clickOnMyImpact));
			          Assert.assertTrue(verMyImpact.isDisplayed());
			         
			            WebDriverWait wait6 = new WebDriverWait(driver, 90);
				    	Thread.sleep(30000);
				        WebElement verLearning = wait6.until(ExpectedConditions.visibilityOfElementLocated(hp.clickOnLearning));
				        Assert.assertTrue(verLearning.isDisplayed());
				        
				        WebDriverWait wait7 = new WebDriverWait(driver, 60);
				          WebElement verContacts = wait7.until(ExpectedConditions.visibilityOfElementLocated(hp.contacts));
				          Assert.assertTrue(verContacts.isDisplayed());
				         
				            WebDriverWait wait8 = new WebDriverWait(driver, 90);
					    	Thread.sleep(30000);
					        WebElement verClincianCommons = wait8.until(ExpectedConditions.visibilityOfElementLocated(hp.clinicianCommons));
					        Assert.assertTrue(verClincianCommons.isDisplayed());
	         
					        WebDriverWait wait9 = new WebDriverWait(driver, 90);
					    	Thread.sleep(30000);
					        WebElement verFavorites = wait9.until(ExpectedConditions.visibilityOfElementLocated(hp.favorites));
					        Assert.assertTrue(verFavorites.isDisplayed());
	         
	         
	            
	    }
	    
	    public void leftNavigationMenuItems() throws Throwable {
	    	WebDriverWait wait = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNav = wait.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationMenuOption));
		    Assert.assertTrue(clkLeftNav.isDisplayed());
		    
		    WebDriverWait wait1 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavHome = wait1.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationHomeOption));
		    Assert.assertTrue(clkLeftNavHome.isDisplayed());
		    
		    WebDriverWait wait2 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavSchedule = wait2.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationScheduleOption));
		    Assert.assertTrue(clkLeftNavSchedule.isDisplayed());
		    
		    WebDriverWait wait3 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavTasks = wait3.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationTasksOption));
		    Assert.assertTrue(clkLeftNavTasks.isDisplayed());
		    
		    WebDriverWait wait4 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavNotifications = wait4.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationNotificationsOption));
		    Assert.assertTrue(clkLeftNavNotifications.isDisplayed());
		    
		    WebDriverWait wait5 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavMyImpact = wait5.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationMyImpactOption));
		    Assert.assertTrue(clkLeftNavMyImpact.isDisplayed());
		    
		    WebDriverWait wait6 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavLearning = wait6.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationLearningOption));
		    Assert.assertTrue(clkLeftNavLearning.isDisplayed());
		    
		    WebDriverWait wait7 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavContacts = wait7.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationContactsOption));
		    Assert.assertTrue(clkLeftNavContacts.isDisplayed());
		    
		    WebDriverWait wait8 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavClinicianCommons = wait8.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationClinicianCommonsOption));
		    Assert.assertTrue(clkLeftNavClinicianCommons.isDisplayed());
		    
		    WebDriverWait wait9 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavFav = wait9.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationFavoritesOption));
		    Assert.assertTrue(clkLeftNavFav.isDisplayed());
		    
		    WebDriverWait wait10 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavLogOut = wait10.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationLogOutOption));
		    Assert.assertTrue(clkLeftNavLogOut.isDisplayed());
		    
		    WebDriverWait wait11 = new WebDriverWait(driver, 90);
		    Thread.sleep(30000);
		    WebElement clkLeftNavHomeagain = wait11.until(ExpectedConditions.visibilityOfElementLocated(lef.clkLeftNavigationHomeOption));
		    Assert.assertTrue(clkLeftNavHomeagain.isDisplayed());
		    clkLeftNavHome.click();
	    }
	    
	    public void clkOnSchedule() throws Throwable {
	    	WebDriverWait waitrs1 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkSchedule = waitrs1.until(ExpectedConditions.visibilityOfElementLocated(hp.clickOnSchedule));
	        clkSchedule.click();
	        System.out.println("Schedule Button clicked");
	    }
	    
	    public void scheduleScreen()throws Throwable{
	    	
	    	WebDriverWait wait = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkSchedule = wait.until(ExpectedConditions.visibilityOfElementLocated(hp.clickOnSchedule));
	        clkSchedule.click();
	        
	        WebDriverWait wait2 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verScheduleHeader = wait2.until(ExpectedConditions.visibilityOfElementLocated(op.verifyScheduleHeader));
	        verScheduleHeader.click();
	        
	        WebDriverWait wait3 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkOnLeftArrow = wait3.until(ExpectedConditions.visibilityOfElementLocated(op.clickOnleftArrow));
	        clkOnLeftArrow.click();
	        
	        WebDriverWait wait4 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement valappointmentHeader = wait4.until(ExpectedConditions.visibilityOfElementLocated(op.appointmentsHeader));
	        valappointmentHeader.click();
	        
	        WebDriverWait wait5 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verName = wait5.until(ExpectedConditions.visibilityOfElementLocated(op.verifyName));
	        verName.click();
	        
	        WebDriverWait wait6 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement clkSchDots = wait6.until(ExpectedConditions.visibilityOfElementLocated(op.clickondots));
	        clkSchDots.click();
	        
	        WebDriverWait wait7 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verAutoCal = wait7.until(ExpectedConditions.visibilityOfElementLocated(op.verifyAutoCall));
	        //verAutoCal.click();
	        
	        WebDriverWait wait8 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verMapRoute = wait8.until(ExpectedConditions.visibilityOfElementLocated(op.verifyMapRoute));
	       // verMapRoute.click();
	        
	        WebDriverWait wait9 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verCallTeamCare = wait9.until(ExpectedConditions.visibilityOfElementLocated(op.verifyCallTeamCare));
	       // verCallTeamCare.click();
	        
	        WebDriverWait wait10 = new WebDriverWait(driver, 90);
	    	Thread.sleep(30000);
	        WebElement verAddNewTask = wait10.until(ExpectedConditions.visibilityOfElementLocated(op.AddNewTask));
//	        verAddNewTask.click();
	        
//	        WebDriverWait wait11 = new WebDriverWait(driver, 90);
//	    	Thread.sleep(30000);
//	        WebElement clkbackToMenu = wait11.until(ExpectedConditions.visibilityOfElementLocated(op.clickbackToMenu));
//	        clkbackToMenu.click();
	        
	        
	    }
	    
	    public void addTasks()throws Throwable{
	    	    WebDriverWait wait10 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement verAddNewTask = wait10.until(ExpectedConditions.visibilityOfElementLocated(op.AddNewTask));
		        verAddNewTask.click();
		        
		        WebDriverWait wait11 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement enterTaskName = wait11.until(ExpectedConditions.visibilityOfElementLocated(adt.taskName));
		        enterTaskName.click();
		        
		        WebDriverWait wait12 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement clkOnCalendar = wait12.until(ExpectedConditions.visibilityOfElementLocated(adt.taskDate));
		        clkOnCalendar.click();
		        
		        WebDriverWait wait13 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement selectDate = wait13.until(ExpectedConditions.visibilityOfElementLocated(adt.selectTaskDate));
		        selectDate.click();
		        
		        WebDriverWait wait14 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement clkOkonCal = wait14.until(ExpectedConditions.visibilityOfElementLocated(adt.clickOkonCal));
		        clkOkonCal.click();
		        
		        WebDriverWait wait15 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement enterTaskNotes = wait15.until(ExpectedConditions.visibilityOfElementLocated(adt.taskNotes));
		        enterTaskNotes.click();
		        
		        WebDriverWait wait16 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement clickSaveChanges = wait16.until(ExpectedConditions.visibilityOfElementLocated(adt.taskSaveChanges));
		        clickSaveChanges.click();
		        
		        WebDriverWait wait17 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement verTaskSuccessMsg = wait17.until(ExpectedConditions.visibilityOfElementLocated(adt.taskSuccessfullyAddedMsg));
		        verTaskSuccessMsg.click();
		        
		        WebDriverWait wait18 = new WebDriverWait(driver, 90);
		    	Thread.sleep(30000);
		        WebElement clkOksuccess = wait18.until(ExpectedConditions.visibilityOfElementLocated(adt.clickOkOnSuccessPopUp));
		        clkOksuccess.click();
		        
		       
	    }
	    
	    public void navigateToPrevDayAppointments() throws Throwable {
	    	System.out.println("coming to prev day arrow method");
	    	WebDriverWait waitrs3 = new WebDriverWait(driver, 60);
	    	WebElement clkLeftArrowPrDayAppntmnsts = waitrs3.until(ExpectedConditions.visibilityOfElementLocated(adt.clickOnLeftArrowPrevDate));
	    	clkLeftArrowPrDayAppntmnsts.click();
	    	System.out.println("prev day arrow method clicked");
	    	Thread.sleep(3000);
	    }
	    
	    public void navigateToCurrDayAppointments() throws Throwable {
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	WebElement clkRightArrowCurrDayAppntmnsts = wait.until(ExpectedConditions.visibilityOfElementLocated(adt.clickOkOnSuccessPopUp));
	    	clkRightArrowCurrDayAppntmnsts.click();
	    	Thread.sleep(3000);
	    }
	    
	    public void navigateToFutureDayAppointments() throws Throwable {
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	WebElement clkLeftArrowFutDayAppntmnsts = wait.until(ExpectedConditions.visibilityOfElementLocated(adt.clickOkOnSuccessPopUp));
	    	clkLeftArrowFutDayAppntmnsts.click();
	    	Thread.sleep(3000);
	    }
	    
	    public void reschedulePrevDayAppointments() throws Throwable {
	    	navigateToPrevDayAppointments();
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	WebElement appointments = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
    		String noAppointmentsFnd=appointments.getText();
	    	String expNoAppointments="No Appointments Found";
	    	System.out.println("No Appointments Found for Previous Day :" +noAppointmentsFnd);
	    	if(expNoAppointments.equals(noAppointmentsFnd)) {
//	    		WebElement appointments = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
//	    		String noAppointmentsFnd=appointments.getText();
		    //	String expNoAppointments="No Appointments Found";
		    	System.out.println("No Appointments Found for Previous Day :" +noAppointmentsFnd);
		    	
	    	}else {
	    		WebElement appointmentsF = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
	    		String AppointmentsFnd=appointmentsF.getText();
	    		System.out.println("Appointments Found :" +AppointmentsFnd);
		    	String expAppointments="Appointments";
		    	System.out.println("Appointments Found for Previous Day :" +AppointmentsFnd);
	    		if(expAppointments.equals(AppointmentsFnd)) {
//	    		WebElement appointmentsFound = wait.until(ExpectedConditions.visibilityOfElementLocated(res.appointmentsFoundONPrevDay));
//		    	String aptmentsFound=appointmentsFound.getText();
//		    	System.out.println("Appoinments Found-"+aptmentsFound);
//		    	String AptHder="Appointments";
//		    	if(aptmentsFound.equals(AptHder)) {
	    			System.out.println("Appointments Found for Previous Day in If loop:" +AppointmentsFnd);
		    	By byXpath = By.xpath("//android.widget.LinearLayout");
		    	List<MobileElement> listofItems = driver.findElements(byXpath);
		    	for (int i=4; i<=listofItems.size(); i++)
		    	{
		    	    //I would suggest you to see if you can improve the selector though
		    	    By by= By.xpath("(//android.widget.LinearLayout)[" + i + "]");
		    	    System.out.println(i);
		    	    WebElement myDynamicElement = wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		    	    System.out.println("Click on first Appointment-"+i);
		    	    //click on apppointment
		    	    myDynamicElement.click();
		    	    //verify reschedule option & click
		    	    WebElement reschdOption = wait.until(ExpectedConditions.visibilityOfElementLocated(res.clickOnReschApp));
		    	    reschdOption.click();
		    	    //resch Date Pick
		    	    rescheduleAppointmentDate();
		    	    
		    	    
		    	   
		    	    
		    	}
		    		}		
		    	}
	    	
	    	
	    }
	    
	    public void clickOnAppointment() throws Throwable {
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	WebElement clkAppointment = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.clkAppointments));
		    clkAppointment.click();
		    Thread.sleep(5000);
	    }
	    
	    public void scheduleDetailScreen() throws Throwable {
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
		    WebElement clkAppointment = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.clkAppointments));
		    clkAppointment.click();
		    Thread.sleep(5000);
		    
		    WebElement valName = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verName));
		    Assert.assertTrue(valName.isDisplayed());
		    
		    WebElement valAddress = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verAddress));
		    Assert.assertTrue(valAddress.isDisplayed());
		    
		    WebElement valAdd2 = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verAddress2));
		    Assert.assertTrue(valAdd2.isDisplayed());
		    
		    WebElement valPhn = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verPhoneNumber));
		    Assert.assertTrue(valPhn.isDisplayed());
		    
		    WebElement valResc = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verReschedule));
		    Assert.assertTrue(valResc.isDisplayed());
		    
		    WebElement valCancel = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verCancel));
		    Assert.assertTrue(valCancel.isDisplayed());
		    
		    WebElement valMemberID = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verMemberID));
		    Assert.assertTrue(valMemberID.isDisplayed());
		    
		    WebElement valMemIDNum = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verMemberIDNum));
		    Assert.assertTrue(valMemIDNum.isDisplayed());
		    
		    WebElement valLogo = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verLogo));
		    Assert.assertTrue(valLogo.isDisplayed());
		    
		    WebElement valLogoName = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verLogoName));
		    Assert.assertTrue(valLogoName.isDisplayed());
		    
		    WebElement valLobheader = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verLobHeader));
		    Assert.assertTrue(valLobheader.isDisplayed());
		    
		    WebElement valLobval = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verLobValue));
		    Assert.assertTrue(valLobval.isDisplayed());
		    
		    WebElement valClientHdr = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verClientHeader));
		    Assert.assertTrue(valClientHdr.isDisplayed());
		    
		    WebElement valClientName = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verClientValue));
		    Assert.assertTrue(valClientName.isDisplayed());
		    
		    WebElement valSubClientHdr = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verSubClientHeader));
		    Assert.assertTrue(valSubClientHdr.isDisplayed());
		    
		    WebElement valSubclientval = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verSubClientValue));
		    Assert.assertTrue(valSubclientval.isDisplayed());
		    
		    WebElement valCDOhdr = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verCDOHeader));
		    Assert.assertTrue(valCDOhdr.isDisplayed());
		    
		    WebElement valCDOval = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verCDOValue));
		    Assert.assertTrue(valCDOval.isDisplayed());
		    
		    WebElement valGroName = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verGroupName));
		    Assert.assertTrue(valGroName.isDisplayed());
		    
		    WebElement valVisInfHdr = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verVisitInformationHeader));
		    Assert.assertTrue(valVisInfHdr.isDisplayed());
		    
		    WebElement valVisInfVal1 = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verVisitInformationValue1));
		    Assert.assertTrue(valVisInfVal1.isDisplayed());
		    
		    WebElement valVisInfVal2 = wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verVisitInformationValue2));
		    Assert.assertTrue(valVisInfVal2.isDisplayed());
		    
		    
	    }
	    
	    public  void addDay() {
	    	
	        //Display the Result in the Edit Text or Text View your Choice
//	        EditText etDOR = (EditText)findViewById(R.id.etDateOfReturn);
//	        etDOR.setText(dateInString);
	        WebDriverWait wait = new WebDriverWait(driver, 60);
	        WebElement selDateRes= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschselectDate));
			 Assert.assertTrue(selDateRes.isDisplayed());
			 String curDate=selDateRes.getText();
			 System.out.println("Current Date"+curDate);
			 
			 int convCutDate=Integer.parseInt(curDate);
			 int addFuDattoCurDate=convCutDate;
			 int adDays=3;
			 int reDate=addFuDattoCurDate+adDays;
			 System.out.println("Add 3 days to current Date"+reDate);
			 
			 WebDriverWait wait01 = new WebDriverWait(driver, 60);
			 By selFD=By.xpath("//android.view.View[@content-desc="+reDate+" April 2023\"]");
		     WebElement selFutDateRes= wait01.until(ExpectedConditions.visibilityOfElementLocated(selFD));
		     Assert.assertTrue(selFutDateRes.isDisplayed());
		     selFutDateRes.click();
		     
		     WebDriverWait waitok = new WebDriverWait(driver, 60);
	    	 WebElement clkReschok= waitok.until(ExpectedConditions.visibilityOfElementLocated(resch.clickOkonrescCal));
			 Assert.assertTrue(clkReschok.isDisplayed());
			 clkReschok.click();
				 
			 
			 
	    }
	    
	    public void rescheduleAppointmentDate() {
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	 WebElement clkResch= wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verReschedule));
			 Assert.assertTrue(clkResch.isDisplayed());
			 
			 WebElement valresDate= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschDate));
			 Assert.assertTrue(valresDate.isDisplayed());
			 valresDate.click();
			 
			 addDay();
			 
//			 WebElement selDateRes= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschselectDate));
//			 Assert.assertTrue(selDateRes.isDisplayed());
//			 selDateRes.click();
//			 
//			 WebElement clkOkResCal= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.clickOkonrescCal));
//			 Assert.assertTrue(clkOkResCal.isDisplayed());
//			 clkOkResCal.click();
			 
			 WebElement clkSearch= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschSearch));
			 Assert.assertTrue(clkSearch.isDisplayed());
			 clkSearch.click();
			 
			 WebElement valNoSlotsHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.selectSlotsavalb));
			 Assert.assertTrue(valNoSlotsHdr.isDisplayed());
			 valNoSlotsHdr.click();
			 
			 WebElement valCommentsHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.verCommentsHeader));
			 Assert.assertTrue(valCommentsHdr.isDisplayed());
			 
			 WebElement entrComments= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.enterComments));
			 entrComments.sendKeys("test");
			 
			 WebElement clkSaveResch= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschSave));
			 Assert.assertTrue(clkSaveResch.isDisplayed());
			 clkSaveResch.click();
			 
			 WebElement valNoSlotsMsg= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.selSlots));
			 Assert.assertTrue(valNoSlotsMsg.isDisplayed());
			 valNoSlotsMsg.click();
			 
			 WebElement clkOKNOSlotsPOPUP= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.clkOkNoSlots));
			 Assert.assertTrue(clkOKNOSlotsPOPUP.isDisplayed());
			 clkOKNOSlotsPOPUP.click();
			 
			 clkOKNOSlotsPOPUP.click();

			 WebElement clkbacktoMenu= wait.until(ExpectedConditions.visibilityOfElementLocated(op.clickbackToMenu));
			 Assert.assertTrue(clkbacktoMenu.isDisplayed());
			 clkbacktoMenu.click();
			 clkbacktoMenu.click();
			 clkbacktoMenu.click();
			 

			 
			 
	    	
	    }
	    
	    
	    
	    public void rescheduleScreen() {
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	 WebElement clkResch= wait.until(ExpectedConditions.visibilityOfElementLocated(sch.verReschedule));
			 Assert.assertTrue(clkResch.isDisplayed());
			 clkResch.click();
			 
			 WebElement valResHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschduleHeader));
			 Assert.assertTrue(valResHdr.isDisplayed());
			 
			 WebElement valReasHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reasonHeader));
			 Assert.assertTrue(valReasHdr.isDisplayed());
			 
			 WebElement valRescByPraHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reshcbyPractValue));
			 Assert.assertTrue(valRescByPraHdr.isDisplayed());
			 
			 WebElement valresDate= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschDate));
			 Assert.assertTrue(valresDate.isDisplayed());
			 valresDate.click();
			 
			 WebElement selDateRes= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschselectDate));
			 Assert.assertTrue(selDateRes.isDisplayed());
			 selDateRes.click();
			 
			 WebElement clkOkResCal= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.clickOkonrescCal));
			 Assert.assertTrue(clkOkResCal.isDisplayed());
			 clkOkResCal.click();
			 
			 WebElement clkSearch= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschSearch));
			 Assert.assertTrue(clkSearch.isDisplayed());
			 clkSearch.click();
			 
			 WebElement valNoSlotsHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.verNoSlotsHeader));
			 Assert.assertTrue(valNoSlotsHdr.isDisplayed());
			 
			 WebElement valCommentsHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.verCommentsHeader));
			 Assert.assertTrue(valCommentsHdr.isDisplayed());
			 
			 WebElement entrComments= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.enterComments));
			 entrComments.sendKeys("test");
			 
			 WebElement clkSaveResch= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.reschSave));
			 Assert.assertTrue(clkSaveResch.isDisplayed());
			 clkSaveResch.click();
			 
			 WebElement valNoSlotsMsg= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.verIfNoSlotsMsg));
			 Assert.assertTrue(valNoSlotsMsg.isDisplayed());
			 
			 WebElement clkOKNOSlotsPOPUP= wait.until(ExpectedConditions.visibilityOfElementLocated(resch.clkOkNoSlots));
			 Assert.assertTrue(clkOKNOSlotsPOPUP.isDisplayed());
			 clkOKNOSlotsPOPUP.click();

			 WebElement clkbacktoMenu= wait.until(ExpectedConditions.visibilityOfElementLocated(op.clickbackToMenu));
			 Assert.assertTrue(clkbacktoMenu.isDisplayed());
			 clkbacktoMenu.click();
			 clkbacktoMenu.click();
			 clkbacktoMenu.click();
			 

			 
	    }

		public void notificationsScreen() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			WebElement clkNotificaionsMenu= wait.until(ExpectedConditions.visibilityOfElementLocated(not.clkNotificationsMenu));
			Assert.assertTrue(clkNotificaionsMenu.isDisplayed());
			clkNotificaionsMenu.click();
			
			WebElement valNotHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(not.verNotificatonsHeader));
			Assert.assertTrue(valNotHdr.isDisplayed());
			
			WebElement valSchHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(not.verScheduleHeader));
			Assert.assertTrue(valSchHdr.isDisplayed());
			
			 WebElement clkbacktoMenu= wait.until(ExpectedConditions.visibilityOfElementLocated(op.clickbackToMenu));
			 Assert.assertTrue(clkbacktoMenu.isDisplayed());
			 clkbacktoMenu.click();
		}

		public void tasksScreen() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			
			WebElement clkTask= wait.until(ExpectedConditions.visibilityOfElementLocated(tal.clkTasksMenu));
			Assert.assertTrue(clkTask.isDisplayed());
			clkTask.click();
			
			 WebElement clkbacktoMenu= wait.until(ExpectedConditions.visibilityOfElementLocated(op.clickbackToMenu));
			 Assert.assertTrue(clkbacktoMenu.isDisplayed());
			 clkbacktoMenu.click();
		}

		public void myImpactScreen() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			WebElement clkMyImpactMenu= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.clkMyImpactsMenu));
			Assert.assertTrue(clkMyImpactMenu.isDisplayed());
			clkMyImpactMenu.click();
			
			WebElement verMyImpHdr= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.verMyImpactHeader));
			Assert.assertTrue(verMyImpHdr.isDisplayed());
			
			WebElement verMarVis= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.verYourMarVisitTotalHeader));
			Assert.assertTrue(verMarVis.isDisplayed());
			
			WebElement verTeam= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.verTeamTotal));
			Assert.assertTrue(verTeam.isDisplayed());
			
			WebElement verGoals= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.verYour2023GoalsHeader));
			Assert.assertTrue(verGoals.isDisplayed());
			
			WebElement verGoalVal= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.verGoalsValues));
			Assert.assertTrue(verGoalVal.isDisplayed());
			
			WebElement verVisits= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.ver2023VisitTotalValue));
			Assert.assertTrue(verVisits.isDisplayed());
			
			WebElement verNetwrk= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.verNetwork2023Header));
			Assert.assertTrue(verNetwrk.isDisplayed());
			
			WebElement verImp= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.verMakingAnImpacHeader));
			Assert.assertTrue(verImp.isDisplayed());
			
			WebElement verCompRate= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.verVisitComplRateHeader));
			Assert.assertTrue(verCompRate.isDisplayed());
			
			WebElement verChartRet= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.chartRetTime));
			Assert.assertTrue(verChartRet.isDisplayed());
			
			WebElement verStarGaps= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.clkStarGaps));
			Assert.assertTrue(verStarGaps.isDisplayed());
			verStarGaps.click();
			
			WebElement verTotGaps= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.totalNoofgapsclose));
			Assert.assertTrue(verTotGaps.isDisplayed());
			
			WebElement verGapsNotCl= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.totalgapsNotclose));
			Assert.assertTrue(verGapsNotCl.isDisplayed());
			
			WebElement verGapsCl= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.gapsconsClosed));
			Assert.assertTrue(verGapsCl.isDisplayed());
			
			WebElement verGaNoCl= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.gapsConsNotClosed));
			Assert.assertTrue(verGaNoCl.isDisplayed());
			
			WebElement VerGClose= wait.until(ExpectedConditions.visibilityOfElementLocated(mi.gapsClose));
			Assert.assertTrue(VerGClose.isDisplayed());
			
			 WebElement clkbacktoMenu= wait.until(ExpectedConditions.visibilityOfElementLocated(op.clickbackToMenu));
			 Assert.assertTrue(clkbacktoMenu.isDisplayed());
			 clkbacktoMenu.click();
			
		}

		public void LearningScreen() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			WebElement clklearningMenu= wait.until(ExpectedConditions.visibilityOfElementLocated(lp.clkLearning));
			Assert.assertTrue(clklearningMenu.isDisplayed());
			
			WebElement verHeaderLearnin= wait.until(ExpectedConditions.visibilityOfElementLocated(lp.verHeaderLearning));
			Assert.assertTrue(verHeaderLearnin.isDisplayed());
			
			WebElement verAudLin= wait.until(ExpectedConditions.visibilityOfElementLocated(lp.verAudLink));
			Assert.assertTrue(verAudLin.isDisplayed());
			
			
			WebElement verVidLin= wait.until(ExpectedConditions.visibilityOfElementLocated(lp.verVidLink));
			Assert.assertTrue(verVidLin.isDisplayed());
			
			verAudLin.click();
			
			WebElement verAudListHeade= wait.until(ExpectedConditions.visibilityOfElementLocated(lp.clkLearning));
			Assert.assertTrue(verAudListHeade.isDisplayed());
			
						
		}

		public void reScheduleCurrDayAppointments() throws Throwable{
			navigateToCurrDayAppointments();
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	WebElement appointments = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
    		String noAppointmentsFnd=appointments.getText();
	    	String expNoAppointments="No Appointments Found";
	    	System.out.println("No Appointments Found for Previous Day :" +noAppointmentsFnd);
	    	if(expNoAppointments.equals(noAppointmentsFnd)) {
//	    		WebElement appointments = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
//	    		String noAppointmentsFnd=appointments.getText();
		    //	String expNoAppointments="No Appointments Found";
		    	System.out.println("No Appointments Found for Previous Day :" +noAppointmentsFnd);
		    	
	    	}else {
	    		WebElement appointmentsF = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
	    		String AppointmentsFnd=appointmentsF.getText();
	    		System.out.println("Appointments Found :" +AppointmentsFnd);
		    	String expAppointments="Appointments";
		    	System.out.println("Appointments Found for Previous Day :" +AppointmentsFnd);
	    		if(expAppointments.equals(AppointmentsFnd)) {
//	    		WebElement appointmentsFound = wait.until(ExpectedConditions.visibilityOfElementLocated(res.appointmentsFoundONPrevDay));
//		    	String aptmentsFound=appointmentsFound.getText();
//		    	System.out.println("Appoinments Found-"+aptmentsFound);
//		    	String AptHder="Appointments";
//		    	if(aptmentsFound.equals(AptHder)) {
	    			System.out.println("Appointments Found for Previous Day in If loop:" +AppointmentsFnd);
		    	By byXpath = By.xpath("");
		    	List<MobileElement> listofItems = driver.findElements(byXpath);
		    	for (int i=1; i<=listofItems.size(); i++)
		    	{
		    	    //I would suggest you to see if you can improve the selector though
		    	    By by= By.xpath("(//android.widget.LinearLayout)[" + i + "]");
		    	    WebElement myDynamicElement = wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		    	    System.out.println(i);
		    	    //click on apppointment
		    	    myDynamicElement.click();
		    	    //verify reschedule option & click
		    	    WebElement reschdOption = wait.until(ExpectedConditions.visibilityOfElementLocated(res.clickOnReschApp));
		    	    reschdOption.click();
		    	    //resch Date Pick
		    	    rescheduleAppointmentDate();
		    	    
		    	    
		    	   
		    	    
		    	}
		    		}		
		    	}
	    	
	    	
	    }

		public void reScheduleNextDayAppointments() throws Throwable{
			navigateToCurrDayAppointments();
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	WebElement appointments = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
    		String noAppointmentsFnd=appointments.getText();
	    	String expNoAppointments="No Appointments Found";
	    	System.out.println("No Appointments Found for Previous Day :" +noAppointmentsFnd);
	    	if(expNoAppointments.equals(noAppointmentsFnd)) {
//	    		WebElement appointments = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
//	    		String noAppointmentsFnd=appointments.getText();
		    //	String expNoAppointments="No Appointments Found";
		    	System.out.println("No Appointments Found for Previous Day :" +noAppointmentsFnd);
		    	
	    	}else {
	    		WebElement appointmentsF = wait.until(ExpectedConditions.visibilityOfElementLocated(res.noAppointmentsFound));
	    		String AppointmentsFnd=appointmentsF.getText();
	    		System.out.println("Appointments Found :" +AppointmentsFnd);
		    	String expAppointments="Appointments";
		    	System.out.println("Appointments Found for Previous Day :" +AppointmentsFnd);
	    		if(expAppointments.equals(AppointmentsFnd)) {
//	    		WebElement appointmentsFound = wait.until(ExpectedConditions.visibilityOfElementLocated(res.appointmentsFoundONPrevDay));
//		    	String aptmentsFound=appointmentsFound.getText();
//		    	System.out.println("Appoinments Found-"+aptmentsFound);
//		    	String AptHder="Appointments";
//		    	if(aptmentsFound.equals(AptHder)) {
	    			System.out.println("Appointments Found for Previous Day in If loop:" +AppointmentsFnd);
		    	By byXpath = By.xpath("");
		    	List<MobileElement> listofItems = driver.findElements(byXpath);
		    	for (int i=1; i<=listofItems.size(); i++)
		    	{
		    	    //I would suggest you to see if you can improve the selector though
		    	    By by= By.xpath("(//android.widget.LinearLayout)[" + i + "]");
		    	    WebElement myDynamicElement = wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		    	    System.out.println(i);
		    	    //click on apppointment
		    	    myDynamicElement.click();
		    	    //verify reschedule option & click
		    	    WebElement reschdOption = wait.until(ExpectedConditions.visibilityOfElementLocated(res.clickOnReschApp));
		    	    reschdOption.click();
		    	    //resch Date Pick
		    	    rescheduleAppointmentDate();
		    	    
		    	    
		    	   
		    	    
		    	}
		    		}		
		    	}
	    	
	    	
	    }


}
