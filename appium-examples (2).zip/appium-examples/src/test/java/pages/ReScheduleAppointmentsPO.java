package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.MobileElement;
import tests.BaseClass;

public class ReScheduleAppointmentsPO extends BaseClass{
	
	By noAppointmentsFound=By.xpath("(//android.widget.TextView)[4]");
	By  clickOnReschApp=By.xpath("(//android.widget.TextView)[10]");
	By appointmentsFoundONPrevDay=By.xpath("");
	By appointmentsFoundONCurrDay=By.xpath("");
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout[2]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.TextView\r\n")
	public List<WebElement> apntmntOne;
	
	public List<MobileElement> apntments(int countAppntment){
		return this.driver.findElements(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ListView/android.widget.LinearLayout["+countAppntment+"]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.TextView"));
	}
	
		public   boolean isElementPresent(By by) {
	        	        try {
	      	               driver.findElement(by).isDisplayed();
	              	               return true ;
	              	       } catch(Exception e ) {
	              	               return false ;
	               }
	       }
			
		
	}
	

