package pages;

import org.openqa.selenium.By;

public class TasksListPO {
	
	By clkTasksMenu=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.support.v4.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup[2]/android.widget.Button");
	By verTasksHeader=By.xpath("");
	By verTaskNameHeader=By.xpath("");
	By verTaskName=By.xpath("");
	By verTaskMarkAsCompleteChBox=By.xpath("");
	By clkTaskDetails=By.xpath("");
	By verTaskDetailsHeader=By.xpath("");
	By verTaskNameDetHeader=By.xpath("");
	By verTaskDateHeader=By.xpath("");
	By verTaskDate=By.xpath("");
	By verTaskNotesHeader=By.xpath("");
	By verTaskNotes=By.xpath("");
	By verTaskAddedByHeader=By.xpath("");
	By verTaskAddedByname=By.xpath("");
	By verTaskAddedByDate=By.xpath("");
	
	//clk back 2 times to go to main menu
	

}
