package tests;

import org.testng.annotations.Test;

import pages.ReusableComponent;

public class ReScheduleAppointmentTest extends BaseClass{
	
	
	 private ReusableComponent reusableComponent;  
	 
	 public ReScheduleAppointmentTest() {
		 this.reusableComponent=new ReusableComponent();
	 }
	 
	    String user_id="shirema5";
		String pass_word="Sharp@901";
		String invalid_passWord="Sharp123";
		 
		@Test
		public void optumLogin() throws Throwable {
			System.out.println("coming to login method");
			
			
			reusableComponent.appLogo();
			
			String userName=user_id;
			String passWord=pass_word;
			
			
			reusableComponent.login(userName,passWord);
		}
		
		@Test
		public void rescheduleAppointment() throws Throwable {
			reusableComponent.clkOnSchedule();
			reusableComponent.reschedulePrevDayAppointments();
			reusableComponent.reScheduleCurrDayAppointments();
			reusableComponent.reScheduleNextDayAppointments();
		}
	

}
