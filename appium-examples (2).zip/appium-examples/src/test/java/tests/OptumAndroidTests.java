package tests;

import org.testng.annotations.Test;
import pages.ReusableComponent;

public class OptumAndroidTests extends BaseClass{
	
	
	 private ReusableComponent reusableComponent;  
	 
	 public OptumAndroidTests() {
		 this.reusableComponent=new ReusableComponent();
	 }
	
	//ReusableComponent rc=new ReusableComponent();
	
	
	String user_id="shirema5";
	String pass_word="Sharp@901";
	String invalid_passWord="Sharp123";
	
	
	@Test
	public void optumInvalidLogin() throws Throwable {
		System.out.println("coming to login method");
		
		
		reusableComponent.appLogo();
		reusableComponent.validateTitle();
		String userName=user_id;
		
		String invalid_pwd=invalid_passWord;
		reusableComponent.invalidlogin(userName,invalid_pwd);
		
	}
	
	@Test
	public void optumLogin() throws Throwable {
		System.out.println("coming to login method");
		
		
		reusableComponent.appLogo();
		reusableComponent.validateTitle();
		String userName=user_id;
		String passWord=pass_word;
		
		
		reusableComponent.login(userName,passWord);
	}
	
	@Test
	public void enterOTP() throws Throwable {
		System.out.println("Skipping for time being");
		reusableComponent.validateOTP();
	}
	
	@Test
	public void validateHomeScreenMenu() throws Throwable {
		reusableComponent.homeMenuItems();
	}
	
	@Test
	public void validateLeftNavigationMenu() throws Throwable {
		reusableComponent.leftNavigationMenuItems();
		
	}
	
	@Test
	public void validateScheduleScreenforFutureDate() throws Throwable {
		reusableComponent.scheduleScreen();
	}
	
	
	
	@Test
	public void validateAddTasksScreen() throws Throwable {
		reusableComponent.addTasks();
	}
	
	@Test
	public void validateScheduleDetailScreen() throws Throwable {
		reusableComponent.scheduleDetailScreen();
		
	}
	
	@Test
	public void validateReScheduleScreen() {
		reusableComponent.rescheduleScreen();
	}
	
	
	
	@Test
	public void validateNotificationsScreen() {
		reusableComponent.notificationsScreen();
	}
	
	@Test
	public void validateTasksMenuScreen() {
		reusableComponent.tasksScreen();
	}
	
	@Test
	public void validateMyImpactScreen() {
		reusableComponent.myImpactScreen();
	}
	
	@Test
	public void validateLearningsScreen() {
		reusableComponent.LearningScreen();
	}
	
}
